package com.example.fastkeyboard

import android.graphics.RectF

enum class Action { TEXT, SPACE, SHIFT, BACKSPACE, ENTER, KEYCODE, PAGE_ALT, PAGE_LETTERS }

enum class Icon { NONE, SHIFT, BACKSPACE, ENTER, UP, DOWN, LEFT, RIGHT }

/**
 * One key. Position is in grid units: the keyboard is 10 units wide,
 * [x] is the left edge, [w] the width, [row] the row index.
 */
class Key(
    val label: String,
    val action: Action,
    val x: Float,
    val row: Int,
    val w: Float,
    val function: Boolean = false,
    val keyCode: Int = 0,
    val longPress: String? = null,
    val repeat: Boolean = false,
    val icon: Icon = Icon.NONE,
    val extL: Float = 0f,   // extra touch area to the left (grid units)
    val extR: Float = 0f,   // extra touch area to the right (grid units)
) {
    val upper: String = label.uppercase()
    val preview: Boolean = action == Action.TEXT   // show popup bubble on press

    val vis = RectF()    // visible key shape
    val cell = RectF()   // touch area
    var pressed = false
    var textSize = 0f
}
