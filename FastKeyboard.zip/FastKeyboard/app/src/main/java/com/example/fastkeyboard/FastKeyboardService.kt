package com.example.fastkeyboard

import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class FastKeyboardService : InputMethodService(), KeyboardView.Listener {

    private var keyboardView: KeyboardView? = null
    private var autoCapsFlags = 0

    override fun onCreateInputView(): View {
        val v = KeyboardView(this)
        v.listener = this
        keyboardView = v
        return v
    }

    // Never use the full-screen "extract" editor in landscape.
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val v = keyboardView ?: return
        val cls = info.inputType and InputType.TYPE_MASK_CLASS

        autoCapsFlags = if (cls == InputType.TYPE_CLASS_TEXT) {
            info.inputType and (InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or
                    InputType.TYPE_TEXT_FLAG_CAP_WORDS or
                    InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS)
        } else 0

        if (!restarting) {
            val numeric = cls == InputType.TYPE_CLASS_NUMBER ||
                    cls == InputType.TYPE_CLASS_PHONE ||
                    cls == InputType.TYPE_CLASS_DATETIME
            v.showPage(if (numeric) KeyboardView.Page.ALT else KeyboardView.Page.LETTERS)
        }
        v.shift = KeyboardView.Shift.OFF
        refreshAutoCaps()
    }

    override fun onText(text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
        val v = keyboardView ?: return
        val c = text[0]
        // One-shot shift turns off after a letter (no IPC needed).
        if (v.shift == KeyboardView.Shift.ON && c.isLetter()) v.shift = KeyboardView.Shift.OFF
        if (autoCapsFlags != 0 &&
            (c == ' ' || autoCapsFlags and InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS != 0)
        ) refreshAutoCaps()
    }

    override fun onKeyCode(keyCode: Int) {
        sendDownUpKeyEvents(keyCode)
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        val noAction = info != null && (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        refreshAutoCaps()
    }

    /** Turns Shift on at the start of a sentence if the text field asks for it. */
    private fun refreshAutoCaps() {
        val v = keyboardView ?: return
        if (v.shift == KeyboardView.Shift.CAPS || autoCapsFlags == 0) return
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        val caps = ic.getCursorCapsMode(info.inputType)
        v.shift = if (caps != 0) KeyboardView.Shift.ON else KeyboardView.Shift.OFF
    }
}
