package com.example.fastkeyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.SparseArray
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Single custom-drawn keyboard view. Keys are committed on finger DOWN for the
 * lowest possible latency (keys that have a long-press character commit on UP).
 */
class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(text: String)
        fun onKeyCode(keyCode: Int)
        fun onEnter()
    }

    enum class Page { LETTERS, ALT }
    enum class Shift { OFF, ON, CAPS }

    companion object {
        // ---- Tweak these ----
        private const val VIBRATE_MS = 18L          // vibration length per key press
        private const val VIBRATE_AMPLITUDE = 160   // 1..255 (only on phones that support it)
        private const val LONG_PRESS_MS = 350L
        private const val REPEAT_START_MS = 350L
        private const val REPEAT_MS = 45L           // repeat speed for backspace / arrows
        private const val BUBBLE_HIDE_MS = 70L      // how long popup stays after release
        private const val DOUBLE_TAP_MS = 350L      // double-tap shift = caps lock
        private const val HEIGHT_PORTRAIT_DP = 250f
        private const val HEIGHT_LANDSCAPE_DP = 190f
    }

    var listener: Listener? = null

    var shift: Shift = Shift.OFF
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var page: Page = Page.LETTERS
        private set

    // ---------- theme ----------
    private class Theme(
        val bg: Int, val key: Int, val func: Int, val pressed: Int,
        val text: Int, val hint: Int, val popup: Int, val popupStroke: Int, val accent: Int,
    )

    private val darkTheme = Theme(
        Color.parseColor("#16181D"), Color.parseColor("#2B2E36"), Color.parseColor("#3B3F4A"),
        Color.parseColor("#5A6275"), Color.parseColor("#ECEFF4"), Color.parseColor("#8A90A0"),
        Color.parseColor("#4A5062"), Color.parseColor("#6B7388"), Color.parseColor("#4C7BEA"),
    )
    private val lightTheme = Theme(
        Color.parseColor("#E3E5EA"), Color.parseColor("#FFFFFF"), Color.parseColor("#C9CDD6"),
        Color.parseColor("#B0B6C4"), Color.parseColor("#1B1D22"), Color.parseColor("#7A8090"),
        Color.parseColor("#FFFFFF"), Color.parseColor("#A0A6B4"), Color.parseColor("#3D6FDB"),
    )
    private var theme = darkTheme

    // ---------- state ----------
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val letterKeys = Layouts.letters()
    private val altKeys = Layouts.alt()
    private var keys: List<Key> = letterKeys

    private val pressed = SparseArray<Key>()
    private var bubbleKey: Key? = null
    private var bubbleText: String? = null
    private var bubbleSeq = 0
    private var lastShiftTap = 0L

    private var padX = 0f
    private var padTop = 0f
    private var padBottom = 0f

    // ---------- paints ----------
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val bubbleRect = RectF()

    // ---------- vibration ----------
    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    private val canVibrate = vibrator?.hasVibrator() == true
    private val vibeEffect: VibrationEffect? =
        if (Build.VERSION.SDK_INT >= 26) {
            val amp = if (vibrator?.hasAmplitudeControl() == true) VIBRATE_AMPLITUDE
            else VibrationEffect.DEFAULT_AMPLITUDE
            VibrationEffect.createOneShot(VIBRATE_MS, amp)
        } else null

    init {
        isHapticFeedbackEnabled = false
        isSoundEffectsEnabled = false
        hintPaint.textSize = dp(10f)
        applyTheme()
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        if (!canVibrate) return
        val v = vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(vibeEffect!!) else v.vibrate(VIBRATE_MS)
    }

    private fun applyTheme() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        theme = if (night) darkTheme else lightTheme
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyTheme()
        requestLayout()
        invalidate()
    }

    // ---------- layout ----------
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val h = dp(if (land) HEIGHT_LANDSCAPE_DP else HEIGHT_PORTRAIT_DP).toInt()
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        padX = dp(3f)
        padTop = dp(10f)       // room above the first row for the popup bubble
        padBottom = dp(6f)
        layoutPage(letterKeys, Layouts.LETTER_ROWS, w.toFloat(), h.toFloat())
        layoutPage(altKeys, Layouts.ALT_ROWS, w.toFloat(), h.toFloat())
    }

    private fun layoutPage(list: List<Key>, rows: Int, w: Float, h: Float) {
        val cellW = (w - 2 * padX) / Layouts.COLS
        val cellH = (h - padTop - padBottom) / rows
        val gap = dp(2.5f)
        for (k in list) {
            val l = padX + k.x * cellW
            val r = padX + (k.x + k.w) * cellW
            val t = padTop + k.row * cellH
            val b = t + cellH
            k.vis.set(l + gap, t + gap, r - gap, b - gap)
            k.cell.set(l - k.extL * cellW, t, r + k.extR * cellW, b)

            var size = if (k.action == Action.TEXT && k.label.length == 1) cellH * 0.40f else cellH * 0.27f
            if (k.icon == Icon.NONE) {
                textPaint.textSize = size
                val maxW = k.vis.width() - dp(6f)
                val tw = textPaint.measureText(k.label)
                if (tw > maxW) size *= maxW / tw
            }
            k.textSize = size
        }
    }

    // ---------- drawing ----------
    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(theme.bg)
        val radius = dp(7f)
        for (k in keys) drawKey(canvas, k, radius)
        bubbleKey?.let { drawBubble(canvas, it) }
    }

    private fun drawKey(c: Canvas, k: Key, radius: Float) {
        val shiftOn = k.action == Action.SHIFT && shift != Shift.OFF
        keyPaint.color = when {
            k.pressed -> theme.pressed
            shiftOn -> theme.accent
            k.function -> theme.func
            else -> theme.key
        }
        c.drawRoundRect(k.vis, radius, radius, keyPaint)

        val fg = if (shiftOn) Color.WHITE else theme.text
        if (k.icon != Icon.NONE) {
            drawIcon(c, k, fg)
            return
        }

        textPaint.color = if (k.action == Action.SPACE) theme.hint else fg
        textPaint.textSize = k.textSize
        val label = if (k.action == Action.TEXT && shift != Shift.OFF) k.upper else k.label
        val y = k.vis.centerY() - (textPaint.ascent() + textPaint.descent()) / 2f
        c.drawText(label, k.vis.centerX(), y, textPaint)

        val hint = k.longPress
        if (hint != null) {
            hintPaint.color = theme.hint
            c.drawText(hint, k.vis.right - dp(4f), k.vis.top + hintPaint.textSize + dp(1f), hintPaint)
        }
    }

    private fun drawIcon(c: Canvas, k: Key, color: Int) {
        val s = min(k.vis.height(), dp(64f)) * 0.2f
        iconPaint.color = color
        c.save()
        c.translate(k.vis.centerX(), k.vis.centerY())
        c.scale(s, s)
        iconPaint.strokeWidth = dp(1.8f) / s
        when (k.icon) {
            Icon.SHIFT -> {
                path.reset()
                path.moveTo(0f, -1f); path.lineTo(1f, 0f); path.lineTo(0.45f, 0f)
                path.lineTo(0.45f, 0.85f); path.lineTo(-0.45f, 0.85f); path.lineTo(-0.45f, 0f)
                path.lineTo(-1f, 0f); path.close()
                iconPaint.style = if (shift != Shift.OFF) Paint.Style.FILL else Paint.Style.STROKE
                c.drawPath(path, iconPaint)
                if (shift == Shift.CAPS) {
                    iconPaint.style = Paint.Style.FILL
                    c.drawRect(-0.45f, 1.05f, 0.45f, 1.3f, iconPaint)
                }
            }
            Icon.BACKSPACE -> {
                path.reset()
                path.moveTo(-1f, 0f); path.lineTo(-0.45f, -0.75f); path.lineTo(1f, -0.75f)
                path.lineTo(1f, 0.75f); path.lineTo(-0.45f, 0.75f); path.close()
                iconPaint.style = Paint.Style.STROKE
                c.drawPath(path, iconPaint)
                c.drawLine(0.05f, -0.3f, 0.6f, 0.3f, iconPaint)
                c.drawLine(0.6f, -0.3f, 0.05f, 0.3f, iconPaint)
            }
            Icon.ENTER -> {
                iconPaint.style = Paint.Style.STROKE
                path.reset()
                path.moveTo(0.9f, -0.7f); path.lineTo(0.9f, 0.15f); path.lineTo(-0.4f, 0.15f)
                c.drawPath(path, iconPaint)
                iconPaint.style = Paint.Style.FILL
                path.reset()
                path.moveTo(-1f, 0.15f); path.lineTo(-0.3f, -0.45f); path.lineTo(-0.3f, 0.75f); path.close()
                c.drawPath(path, iconPaint)
            }
            Icon.UP, Icon.DOWN, Icon.LEFT, Icon.RIGHT -> {
                val deg = when (k.icon) {
                    Icon.UP -> 0f
                    Icon.RIGHT -> 90f
                    Icon.DOWN -> 180f
                    else -> 270f
                }
                c.rotate(deg)
                path.reset()
                path.moveTo(0f, -1f); path.lineTo(1f, 0.8f); path.lineTo(-1f, 0.8f); path.close()
                iconPaint.style = Paint.Style.FILL
                c.drawPath(path, iconPaint)
            }
            else -> {}
        }
        c.restore()
    }

    private fun drawBubble(c: Canvas, k: Key) {
        val text = bubbleText ?: return
        val bw = max(k.vis.width() + dp(18f), dp(54f))
        val bh = min(k.cell.height() * 1.15f, dp(70f))
        val left = (k.vis.centerX() - bw / 2f).coerceIn(dp(2f), max(dp(2f), width - dp(2f) - bw))
        var bottom = k.vis.top + dp(3f)
        var top = bottom - bh
        if (top < 0f) {          // top row: no room above, so cover the key itself
            top = 0f
            bottom = bh
        }
        bubbleRect.set(left, top, left + bw, bottom)
        val r = dp(10f)
        keyPaint.color = theme.popup
        c.drawRoundRect(bubbleRect, r, r, keyPaint)
        strokePaint.color = theme.popupStroke
        strokePaint.strokeWidth = dp(1f)
        c.drawRoundRect(bubbleRect, r, r, strokePaint)

        textPaint.color = theme.text
        textPaint.textSize = bh * 0.52f
        val y = bubbleRect.centerY() - (textPaint.ascent() + textPaint.descent()) / 2f
        c.drawText(text, bubbleRect.centerX(), y, textPaint)
    }

    // ---------- page / shift ----------
    fun showPage(p: Page) {
        if (page == p) return
        releaseAll()
        page = p
        keys = if (p == Page.LETTERS) letterKeys else altKeys
        invalidate()
    }

    private fun toggleShift() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == Shift.CAPS -> Shift.OFF
            shift == Shift.ON && now - lastShiftTap < DOUBLE_TAP_MS -> Shift.CAPS
            shift == Shift.ON -> Shift.OFF
            else -> Shift.ON
        }
        lastShiftTap = now
    }

    // ---------- key actions ----------
    private fun fire(k: Key) {
        val l = listener
        when (k.action) {
            Action.TEXT -> l?.onText(if (shift != Shift.OFF) k.upper else k.label)
            Action.SPACE -> l?.onText(" ")
            Action.BACKSPACE -> l?.onKeyCode(KeyEvent.KEYCODE_DEL)
            Action.ENTER -> l?.onEnter()
            Action.KEYCODE -> l?.onKeyCode(k.keyCode)
            Action.SHIFT -> toggleShift()
            Action.PAGE_ALT -> showPage(Page.ALT)
            Action.PAGE_LETTERS -> showPage(Page.LETTERS)
        }
    }

    // ---------- long-press / repeat timer ----------
    private var timerKey: Key? = null
    private var timerPointer = -1
    private val timerRunnable = object : Runnable {
        override fun run() {
            val k = timerKey ?: return
            if (k.repeat) {
                fire(k)
                postDelayed(this, REPEAT_MS)
            } else {
                val lp = k.longPress ?: return
                timerKey = null
                vibrate()
                bubbleText = lp
                invalidate()
                listener?.onText(lp)
            }
        }
    }

    private fun startTimer(id: Int, k: Key, delay: Long) {
        cancelTimer()
        timerPointer = id
        timerKey = k
        postDelayed(timerRunnable, delay)
    }

    private fun cancelTimer() {
        removeCallbacks(timerRunnable)
        timerKey = null
        timerPointer = -1
    }

    /** A key with a pending long-press is committed as a normal tap if another key is pressed first. */
    private fun flushPending() {
        val k = timerKey ?: return
        if (!k.repeat) {
            cancelTimer()
            fire(k)
        }
    }

    // ---------- touch ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                requestUnbufferedDispatch(e)   // lower input latency
                onPointerDown(e.getPointerId(0), e.getX(0), e.getY(0))
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                onPointerDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                if (pressed.size() > 0) {
                    for (i in 0 until e.pointerCount) onPointerMove(e.getPointerId(i), e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP ->
                onPointerUp(e.getPointerId(e.actionIndex), true)
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }

    private fun keyAt(x: Float, y: Float): Key? {
        val cx = x.coerceIn(padX + 1f, width - padX - 1f)
        val cy = y.coerceIn(padTop + 1f, height - padBottom - 1f)
        for (k in keys) if (k.cell.contains(cx, cy)) return k
        return null
    }

    private fun onPointerDown(id: Int, x: Float, y: Float) {
        flushPending()
        val k = keyAt(x, y) ?: return
        pressed.put(id, k)
        k.pressed = true
        if (k.preview) {
            bubbleKey = k
            bubbleText = if (shift != Shift.OFF) k.upper else k.label
            bubbleSeq++
        }
        vibrate()
        invalidate()
        when {
            k.repeat -> {
                fire(k)
                startTimer(id, k, REPEAT_START_MS)
            }
            k.longPress != null -> startTimer(id, k, LONG_PRESS_MS)
            else -> fire(k)
        }
    }

    private fun onPointerMove(id: Int, x: Float, y: Float) {
        val k = pressed.get(id) ?: return
        val slop = dp(10f)
        if (x < k.cell.left - slop || x > k.cell.right + slop ||
            y < k.cell.top - slop || y > k.cell.bottom + slop
        ) onPointerUp(id, false)   // finger slid off the key: cancel
    }

    private fun onPointerUp(id: Int, commit: Boolean) {
        val k = pressed.get(id) ?: return
        pressed.remove(id)
        k.pressed = false

        if (id == timerPointer) {
            val pending = timerKey
            cancelTimer()
            if (commit && pending != null && !pending.repeat) fire(pending)
        }

        if (bubbleKey === k) {
            val seq = bubbleSeq
            postDelayed({
                if (seq == bubbleSeq) {
                    bubbleKey = null
                    invalidate()
                }
            }, BUBBLE_HIDE_MS)
        }
        invalidate()
    }

    private fun releaseAll() {
        for (i in 0 until pressed.size()) pressed.valueAt(i).pressed = false
        pressed.clear()
        cancelTimer()
        bubbleKey = null
        invalidate()
    }

    override fun onDetachedFromWindow() {
        releaseAll()
        super.onDetachedFromWindow()
    }
}
