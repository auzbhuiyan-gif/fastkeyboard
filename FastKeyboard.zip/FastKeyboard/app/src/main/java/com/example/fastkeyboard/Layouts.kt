package com.example.fastkeyboard

import android.view.KeyEvent

/**
 * All key layouts live here. Edit this file to change keys.
 *
 * Letters page : 4 rows (QWERTY, no number row).
 * Alt page     : 5 rows
 *                row 0 = symbol row
 *                rows 1-3 = number keypad (left) | gap | arrow pad (right)
 *                row 4 = ABC, 0, '.'  | ',', space, backspace, enter
 */
object Layouts {
    const val COLS = 10f
    const val LETTER_ROWS = 4
    const val ALT_ROWS = 5

    // Symbol row on the alt page: key to long-press character.
    // Add or remove entries freely; keys share the width automatically.
    private val SYMBOLS = listOf(
        "!" to "\"", "@" to "~", "#" to "^", "\$" to "€", "%" to "|", "&" to "\\",
        "*" to "/", "-" to "_", "+" to "=", "(" to "[", ")" to "]", "?" to "'",
    )

    fun letters(): List<Key> {
        val k = ArrayList<Key>()
        "qwertyuiop".forEachIndexed { i, c ->
            k += Key(c.toString(), Action.TEXT, i.toFloat(), 0, 1f)
        }
        "asdfghjkl".forEachIndexed { i, c ->
            k += Key(
                c.toString(), Action.TEXT, 0.5f + i, 1, 1f,
                extL = if (i == 0) 0.5f else 0f,
                extR = if (i == 8) 0.5f else 0f,
            )
        }
        k += Key("shift", Action.SHIFT, 0f, 2, 1.5f, function = true, icon = Icon.SHIFT)
        "zxcvbnm".forEachIndexed { i, c ->
            k += Key(c.toString(), Action.TEXT, 1.5f + i, 2, 1f)
        }
        k += Key("del", Action.BACKSPACE, 8.5f, 2, 1.5f, function = true, repeat = true, icon = Icon.BACKSPACE)

        k += Key("?123", Action.PAGE_ALT, 0f, 3, 1.3f, function = true)
        k += Key(",", Action.TEXT, 1.3f, 3, 1f, longPress = "!")
        k += Key("space", Action.SPACE, 2.3f, 3, 4f)
        k += Key(".", Action.TEXT, 6.3f, 3, 1f, longPress = "?")
        k += Key("'", Action.TEXT, 7.3f, 3, 1f, longPress = "\"")
        k += Key("enter", Action.ENTER, 8.3f, 3, 1.7f, function = true, icon = Icon.ENTER)
        return k
    }

    fun alt(): List<Key> {
        val k = ArrayList<Key>()

        // Row 0: symbol row
        val sw = COLS / SYMBOLS.size
        SYMBOLS.forEachIndexed { i, (c, lp) ->
            k += Key(c, Action.TEXT, i * sw, 0, sw, longPress = lp)
        }

        // Number keypad: left block, x = 0 .. 4.5
        val nw = 1.5f
        var n = 1
        for (r in 1..3) {
            for (c in 0..2) {
                k += Key(n.toString(), Action.TEXT, c * nw, r, nw)
                n++
            }
        }
        k += Key("ABC", Action.PAGE_LETTERS, 0f, 4, nw, function = true)
        k += Key("0", Action.TEXT, nw, 4, nw)
        k += Key(".", Action.TEXT, 2 * nw, 4, nw, longPress = ":")

        // Navigation pad: right block, x = 5.5 .. 10 (1 unit gap from the keypad)
        val nx = 5.5f
        k += nav("up", KeyEvent.KEYCODE_DPAD_UP, nx + nw, 1, nw, Icon.UP)
        k += nav("left", KeyEvent.KEYCODE_DPAD_LEFT, nx, 2, nw, Icon.LEFT)
        k += nav("down", KeyEvent.KEYCODE_DPAD_DOWN, nx + nw, 2, nw, Icon.DOWN)
        k += nav("right", KeyEvent.KEYCODE_DPAD_RIGHT, nx + 2 * nw, 2, nw, Icon.RIGHT)
        k += nav("Del", KeyEvent.KEYCODE_FORWARD_DEL, nx, 3, 3 * nw)

        // Bottom row, right side
        k += Key(",", Action.TEXT, nx, 4, 0.8f, longPress = ";")
        k += Key("space", Action.SPACE, nx + 0.8f, 4, 1.5f)
        k += Key("del", Action.BACKSPACE, nx + 2.3f, 4, 1.1f, function = true, repeat = true, icon = Icon.BACKSPACE)
        k += Key("enter", Action.ENTER, nx + 3.4f, 4, 1.1f, function = true, icon = Icon.ENTER)
        return k
    }

    private fun nav(label: String, code: Int, x: Float, row: Int, w: Float, icon: Icon = Icon.NONE) =
        Key(label, Action.KEYCODE, x, row, w, function = true, keyCode = code, repeat = true, icon = icon)
}
